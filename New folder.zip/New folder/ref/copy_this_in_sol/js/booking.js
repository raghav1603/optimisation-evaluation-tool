function getTimeslot(){
    let url= "http://127.0.0.1:5500/concert.json";
	let xhr = new XMLHttpRequest();
	xhr.open('GET', url);
	// console.log(xhr);
	xhr.onload = function () {
        obj = JSON.parse(xhr.responseText);

        let data = document.getElementById('event').value

        let duration = obj[data].duration;
        let availability = obj[data].availability;

        let noOfTickets= document.getElementById("not").value;

        checkAvailability(availability,noOfTickets);
        availabilityError  = document.getElementById('availabilityError').innerHTML;
        // console.log(availabilityError)
        if(availabilityError.length==0) {
            document.getElementById('message').innerHTML = "You are booking "+noOfTickets+" tickets for "+duration+" slot."
        }else{
            document.getElementById('message').innerHTML = ""
        }
    }
    
    xhr.send();
}

function changeToUpper(){
    name=document.getElementById('user').value;
    name_uppercase= name.toUpperCase();
    document.getElementById('user').value = name_uppercase;
}

function checkAvailability(availability,noOfTickets){

    if(noOfTickets>availability){
        document.getElementById("availabilityError").innerHTML="Sorry! Only "+availability+" seats available per booking";
        document.getElementById("btn").disabled = true
    }
    else{
        document.getElementById("availabilityError").innerHTML="";
    }
    
}

function checkDate(){
    
    var concertDate= document.getElementById("doc").value;
    var user_today = new Date(concertDate);
    var today = new Date();
    if (user_today<today) {
        document.getElementById("dateError").innerHTML = "Concert date should be greater than today.";
        document.getElementById("btn").disabled = true
    }
    else {
        document.getElementById("dateError").innerHTML = ""
        document.getElementById("btn").disabled = false
    } 
}

function book(e){
    let NoOfTickets = document.getElementById('not').value;
    let event = document.getElementById('event').value;
        fareObj = {
                    "Light music":350,
                    "Classics":450,
                    "Rock music":400,
                    }
        var fare = 0
        for(let key in fareObj) {
            if (event == key) {
                fare = fareObj[key]
            }
        }
    var message ="Tickets booked for "+event+". You have to pay Rs."+ NoOfTickets*fare+".";
    document.getElementById('successMessage').innerHTML = message;
    e.preventDefault();
   
}



