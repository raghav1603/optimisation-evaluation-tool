/**
 * Index.html API
 */


function checkForStyle(tagName, cssProperty, cssValue) {
    try {
        console.log("Style "+$(tagName).css(cssProperty).replace(/ /g,''));
        return $(tagName).css(cssProperty).replace(/ /g, '') == cssValue.replace(/ /g, '');
    } catch (e) {
        console.error(e);
        return false;
    }
}

function checkStyleForID(id, cssProperty, cssValue) {
    try {
        //console.log("Style ID "+$("#"+id).css(cssProperty).replace(/ /g,''));
        return $("#"+id).css(cssProperty).replace(/ /g, '') == cssValue.replace(/ /g, '');
    } catch (e) {
        //console.error(e);
        return false;
    }
}

/**
 * This checks if navbar structure is correct
 */
// FOR Bootstrap 4
function checkNavBarStructure() {
    try {
        //console.log("******* Checking Nav bar structure *********")
        //console.log($("nav").closest(".navbar").length)
        if ($("nav").closest(".navbar").length>=1) {
            return true;
        } else {
            return false;

        }
    } catch (e) {
        console.error(e);
        return false;
    }
}


/**
 * This checks is the navbar has a navbar brand or not
 */
function checkNavBarHeader() {
    try {
        if ($("nav>div").first().closest(".navbar-header").length>=1) {
            if ($("nav>div>a").length == 1) {
                if ($("nav>div>a").closest(".navbar-brand").length>=1) {
                    return true;
                }
            }
        }
    } catch (e) {
        console.error(e);
        return false;
    }
    return false;
}

/**
 * This checks if there is one link in the navbar
 */
function checkNavBarLink() {
    try {
        if ($("nav li>a").length == 1) {
            //can have an if condition to check if the href link is same as said in index.html
            return true;
        }
        return false;
    } catch (e) {
        console.error(e);
        return false;
    }
}

/**
 * This checks if the brandname is correct or not
 * @param {*} brandName 
 */
function checkNavBarBrandName() {
    try {
        return ($("nav>a").text().trim().toLowerCase().length > 1)
    } catch (e) {
        console.error(e);
        return false;
    }
}

/**
 * This checks if the tag has the given class or not
 * @param {*} className 
 */
function checkClassNameForTag(tagName, className) {
    try {
        if ($(tagName).closest("." + className).length>=1) {
            return true;
        } else {
            return false;
        }
    } catch (e) {
        console.error(e);
        return false;
    }
}

/**
 * This checks if the element with ID has the given class or not
 * @param {*} className 
 */
function checkClassNameForElement(id, className) {
    try {
        if ($("#" + id).closest("." + className).length>=1) {
            return true;
        } else {
            return false;
        }
    } catch (e) {
        console.error(e);
        return false;
    }
}


/**
 * Checks if a given tag exists only once
 * @param {*} tagName 
 */
function isTagPresent(tagName) {
    try {
        if ($(tagName).length == 1) {
            return true;
        } else {
            return false;
        }
    } catch (e) {
        console.error(e);
        return false;
    }
}


/**
 * Checks if an element is present with an ID or not
 * @param {*} id 
 */
function isElementPresent(id) {
    try {
        if ($("#" + id).length == 1) {
            return true;
        } else {
            return false;
        }
    } catch (e) {
        console.error(e);
        return false;
    }
}

/**
 * Checks if the text in a given tag is correct or not
 * @param {*} tagName 
 * @param {*} text 
 */
function checkTagText(tagName) {
    try {
        var text = $(tagName).text()
        if (text.length > 1) {
            return true
        }
        return false
    } catch (e) {
        console.error(e);
        return false;
    }
}


/**
 * Checks if the text in a given ID is correct or not
 * @param {*} tagName 
 * @param {*} text 
 */
function checkElementText(id, text) {
    try {
        return $("#" + id).text().trim().toLowerCase() == text.toLowerCase();
    } catch (e) {
        console.error(e);
        return false;
    }
}

/**
 * Checks whether a form element of a given ID is properly sturctured or not
 * 
 */
function checkFormElementStructure(id) {
    try {
        // console.log($("#"+id).parent().prev().text())
        return $("#" + id).prev("label").parent(".form-group").length == 1
    } catch (e) {
        console.error(e);
        return false;
    }
}

/**
 * Checks if a label is present for the given form elemenent with a specific ID
 * @param {*} id 
 */
function checkLabelPresent(id) {
    try {
        return $("#" + id).prev("label").attr("for") == id;
    } catch (e) {
        console.error(e);
        return false;
    }
}

function checkPlaceholder(id) {
    try {
        return $("#" + id).attr("placeholder").length >= 1;
    } catch (e) {
        console.error(e);
        return false;
    }
}


/**
 * Check if a given element of a specific ID has a given attributes and value
 * @param {*} id 
 * @param {*} attrName 
 * @param {*} value 
 */
function checkAttributeForElement(id, attrName, value) {
    try {
        //console.log("********** check attr **********")
        //console.log($("#" + id).attr(attrName))
        //console.log($("#" + id).attr(attrName).toLowerCase())
        //console.log(value.toLowerCase())
        if ($("#" + id).attr(attrName) == undefined) {
            return value == "text";
        } else {
            return $("#" + id).attr(attrName).toLowerCase() == value.toLowerCase();
        }
    } catch (e) {
        console.error(e);
        return false;
    }
}

/**
 * Check if a given element of a specific tagName has a given attributes and value
 * @param {*} id 
 * @param {*} attrName 
 * @param {*} value 
 */
function checkAttributeForTag(tagName, attrName, value) {
    try {
        // console.log("Check "+$(tagName+"["+attrName+"='"+value+"']").length);
        return $(tagName + "[" + attrName + "='" + value + "']").length >= 1
    } catch (e) {
        console.error(e);
        return false;
    }
}

/**
 * check if particular attribute(without value)  is present for given ID
 * @param {*} id 
 * @param {*} attrName 
 */
function checkAttribute(id, attrName) {
    try {
        var element = document.getElementById(id);
        for (var i = 0, atts = element.attributes, n = atts.length, attrArr = []; i < n; i++) {
            attrArr.push(atts[i].nodeName);
        }
        for (var i = 0; i < attrArr.length; i++) {
            if (attrArr[i] == attrName) {
                return true
            }
        }
        return false
    } catch (e) {
        console.error(e);
        return false;
    }
}

/**
 * Checks if the form grid is correct
 */

//FOR bootstrap 4


/**
 * Checks if the  grid is correct
 */
function checkRowCount(count) {
    try {
        return $(".row").length == count;
    } catch (e) {
        console.log(e);
        return false;
    }
}

function checkColumnCount(rowNumber, columnCount) {
    try {
        //console.log($(".row:eq(0)").html());
        //console.log("Checking column count for row " + rowNumber + " and column count" + columnCount + ": $(.row:nth-child(" + rowNumber + ")");
        //console.log($(".row:eq(" + (rowNumber - 1) + ")").find("div").length);
        return $(".row:eq(" + (rowNumber - 1) + ")").find("div").length == columnCount;
    } catch (e) {
        console.log(e);
        return false;
    }
}



/**
 * Checks if correct number of radio buttons are present
 * @param {*} radioId 
 * @param {*} attribute 
 * @param {*} valueArr 
 */
function checkRadio(count) {
    try {
        // console.log($("input[type='radio']").length)
        if ($("input[type='radio']").length == count) {
            var firstRadioName = $("input[type='radio']").first().attr("name");
            if ($("input[name='" + firstRadioName + "']").length == count) {
                return true;
            } else {
                return false;
            }
        }
        return false
    } catch (e) {
        console.error(e);
        return false;
    }
}

function checkRadioStructure(id) {
    try {
        // console.log("radio structure",$("#"+id).parent().closest(".form-check-inline").length); //check for div?
        return $("#" + id).parent().closest(".form-check-inline").length == 1
    } catch (e) {
        console.error(e);
        return false;
    }
}

/**
 * Checks if a drop down with given ID has the specific number of options
 * @param {*} id 
 * @param {*} noOfItems 
 */
function checkDropDownLength(id, noOfItems) {
    try {
        options = $("#" + id).children();
        //console.log("checkDropDownLength",options.length,noOfItems);
        if (options.length != noOfItems) {
            return false;
        } else {
            return true;
        }
    } catch (e) {
        console.error(e);
        return false;
    }
}

/**
 * Checks if the drop drown with a specific ID has the given options and values
 * @param {*} id 
 * @param {*} optionsArr 
 */
function checkDropDownOptions(id, optionsArr) {
    try {
        currentOptions = $("#" + id).find("option")
        currentOptionsArr = [];
        for (var i = 0; i < currentOptions.length; i++) {
            currentOptionsArr.push($(currentOptions[i]).text().trim())
        }
        // console.log(currentOptionsArr.sort().join(","));
        //if (optionsArr.sort().join(",").toLowerCase() == currentOptionsArr.sort().join(",").toLowerCase()) {
        if (currentOptionsArr.sort().join(",").toLowerCase().length > 1) {
            return true;
        } else {
            return false;
        }
    } catch (e) {
        console.error(e);
        return false;
    }

}

/**
 * Checks if the values given gor the dropdown options are correct or not
 * @param {*} id 
 * @param {*} valueArr 
 */
function checkValuesForDropdown(id, valueArr) {
    try {
        var optionArr = $("#" + id).find("option");
        var optionValueArr = []
        for (let i = 0; i < optionArr.length; i++) {
            optionValueArr.push($(optionArr[i]).attr("value"))
        }
        // console.log("optionValueArr", optionValueArr.join(",").split().sort().join().toLowerCase());
        // console.log("Value Arr" + valueArr.join(",").split().sort().join().toLowerCase())
        if (valueArr.join(",").split().sort().join().toLowerCase() == optionValueArr.join(",").split().sort().join().toLowerCase()) {
            return true;
        } else {
            return false;
        }
    } catch (e) {
        console.error(e);
        return false;
    }
}

function checkFormGrid(inputMap) {
    try {
        for (let key in inputMap) {
            var length = inputMap[key].length
            classArray = inputMap[key]
            // console.log(classArray);    
            // console.log("length",length);
            for (var i = 0; i < length; i++) {
                console.log("here",$(".row div:nth-child("+key+")").hasClass(classArray[i]))
                if ($(".row div:nth-child(" + key + ")").hasClass(classArray[i]) == false) {
                    return false
                } else {
                    return true
                }
            }
        }
    } catch (e) {
        console.error(e);
        return false;
    }
}

function testFunction(inputMap, outputMap, functionName, parameters) {
    try {
        for (let key in inputMap) {
            var elementType = ($("#" + key).attr("type"));
            // console.log("Type " + elementType + " ID " + key);
            if (elementType == "radio" || elementType == "checkbox") {
                $("#" + key).prop("checked", inputMap[key])
            } else {
                document.getElementById(key).value = inputMap[key];
                // console.log("there "+document.getElementById(key).value,"provided:"+inputMap[key], key)
            }
        }
        if (parameters != null) {
            // console.log(parameters)
            functionName(parameters);
        } else {
            functionName()
        }
        for (var key in outputMap) {

            message = document.getElementById(key).innerText.toLowerCase();
            // console.log("message",message,key);
            var indexOfVal = message.indexOf(outputMap[key].toLowerCase());
            // console.log("indexOfVal",indexOfVal)
            if (indexOfVal == -1) {
                return false
            }
            return true;
        }
    } catch (e) {
        console.error("In tool",e);
        console.log("******* returning false********")
        return false;
    }

}

function testFunction2(inputMap, outputMap, functionName, parameters) {
    try {
        for (let key in inputMap) {
            var elementType = ($("#" + key).attr("type"));
            // console.log("Type " + elementType + " ID " + key);
            if (elementType == "radio" || elementType == "checkbox") {
                $("#" + key).prop("checked", inputMap[key])
            } else {
                document.getElementById(key).value = inputMap[key];
                // console.log("there "+document.getElementById(key).value,"provided:"+inputMap[key], key)
            }
        }
        if (parameters != null) {
            functionName(parameters);
        } else {
            functionName()
        }
        for (var key in outputMap) {
            if(document.getElementById(key).value == outputMap[key]){
                return true
            } else {
                return false
            }
        }
    } catch (e) {
        console.error("In tool",e);
        console.log("******* returning false********")
        return false;
    }
}

function testFunction3(inputMap, outputMap, functionName, parameters) {
    try {
        for (let key in inputMap) {
            var elementType = ($("#" + key).attr("type"));
            if (elementType == "radio" || elementType == "checkbox") {
                $("#" + key).prop("checked", inputMap[key])
            } else {
                document.getElementById(key).value = inputMap[key];
                // console.log("there "+document.getElementById(key).value,"provided:"+inputMap[key], key)
            }
        }
        if (parameters != null) {
            functionName(parameters);
        } else {
            functionName()
        }

        for (var key in outputMap) {
            var elementType = ($("#" + key).attr("type"));
            if (elementType == "radio" || elementType == "checkbox") {
                return $("#" + key).prop("checked") == outputMap[key];
            } else {
                return document.getElementById(key).value == outputMap[key];
                // console.log("there "+document.getElementById(key).value,"provided:"+inputMap[key], key)
            }
        }
    } catch (e) {
        console.error("In tool",e);
        console.log("******* returning false********")
        return false;
    }
}

    function testFunction4(inputMap, outputMap, functionName, parameters) {
        try {
            for (let key in inputMap) {
                var elementType = ($("#" + key).attr("type"));
                if (elementType == "radio" || elementType == "checkbox") {
                    $("#" + key).prop("checked", inputMap[key])
                } else {
                    document.getElementById(key).value = inputMap[key];
                    // console.log("there "+document.getElementById(key).value,"provided:"+inputMap[key], key)
                }
            }
            if (parameters != null) {
                functionName(parameters);
            } else {
                functionName()
            }
    
            for (var key in outputMap) {
                var elementType = ($("#" + key).attr("type"));
                if (elementType == "radio" || elementType == "checkbox") {
                    return $("#" + key).prop("disbaled") == outputMap[key];
                } else {
                    return document.getElementById(key).disabled == outputMap[key];
                    // console.log("there "+document.getElementById(key).value,"provided:"+inputMap[key], key)
                }
            }
        } catch (e) {
            console.error("In tool",e);
            console.log("******* returning false********")
            return false;
        }

    }

function checkMessage(id){
    try{
        //console.log(" id",id,"message",document.getElementById(id).innerHTML);
        var message = document.getElementById(id).innerHTML
        return message.length>1

    }catch (e) {
        console.error(e);
        return false;
    }
}


function checkButtonDisability(id, status) {
    try {
        return document.getElementById(id).disabled == status;
    } catch (e) {
        console.error(e);
        return false;
    }
}

function testAjaxFunction(inputMap, functionName, parameters) {
    try {

        for (let key in inputMap) {
            document.getElementById(key).value = inputMap[key];
            console.log(document.getElementById(key).value, inputMap[key])
        }
        if (parameters != null) {
            functionName(parameters);
        } else {
            functionName()
        }
    } catch (e) {
        console.log(e);
    }

}
