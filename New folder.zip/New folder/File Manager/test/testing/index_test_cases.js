$(document).ready(function () {

    var testcases = {};
    
    var testcase1 = checkNavBarStructure();
    if (testcase1) {
        testcases.testcase1 = 0.5;  
    } else {
        testcases.testcase1 = 0;
    }

    var testcase2 = checkClassNameForTag("nav","bg-dark");
    if (testcase2) {
        testcases.testcase2 = 0.25;  
    } else {
        testcases.testcase2 = 0;
    }


    var testcase3 = checkClassNameForTag("nav","navbar-dark");
    if (testcase3) {
        testcases.testcase3 = 0.5;
    } else {
        testcases.testcase3 = 0;
    }

    var testcase7 = checkNavBarBrandName();
    if (testcase7) {
        testcases.testcase7 = 0.25;
    } else {
        testcases.testcase7 = 0;
    }

    var testcase8 = checkAttributeForTag("a","href","booking.html");
    if (testcase8) {
        testcases.testcase8 = 0.5;  
    } else {
        testcases.testcase8 = 0;       //3
    }
/******************************************************************************************** */

    var testcase9 = isTagPresent("h5");
    if (testcase9) {
        testcases.testcase9 = 0.5;
    } else {
        testcases.testcase9 = 0;       //3
    }
    
/******************************************************************************************************* */
        
    var testcase17 = checkForStyle("img","border-width","4px")
    if (testcase17) {
        testcases.testcase17 = 0.5;
    } else {
        testcases.testcase17 = 0;
    }

    var testcase18 = checkForStyle("img","border-color","rgba(51,50,50,0.635)")
    if (testcase18) {
        testcases.testcase18 = 0.5;
    } else {
        testcases.testcase18 = 0;
    } 

    var testcase55 = checkForStyle("img","border-style","solid")
    if (testcase55) {
        testcases.testcase55 = 0.5;
    } else {
        testcases.testcase55 = 0;
    }

    var testcase52 = checkForStyle("p","font-size","20px")
    if (testcase52) {
        testcases.testcase52 = 0.5;
    } else {
        testcases.testcase52 = 0;
    } 

    var testcase53 = checkForStyle("p","font-weight","700")
    if (testcase53) {
        testcases.testcase53 = 0.5;
    } else {
        testcases.testcase53 = 0;
    } 

    var testcase54 = checkForStyle("p","font-style","italic")
    if (testcase54) {
        testcases.testcase54 = 0.5;
    } else {
        testcases.testcase54 = 0;
    } 	
    
/************************************************************************* */
//structure

    var testcase22 = checkRowCount(2);
    if (testcase22) {
        testcases.testcase22 = 1;
    } else {
        testcases.testcase22 = 0;
    }


    var inputMap23 = {
        1:["col-md-10","offset-md-2"]
    }

    var testcase23 = checkFormGrid(inputMap23)
    if (testcase23) {
        testcases.testcase23 = 0.5;
    } else {
        testcases.testcase23 = 0;
    }
	
	
    var inputMap51 = {
        1:["col-md-4","offset-md-4"]
    }

    var testcase51 = checkFormGrid(inputMap51)
    if (testcase51) {
        testcases.testcase51 = 0.5;
    } else {
        testcases.testcase51 = 0;
    }
	
	var testcase50 = checkClassNameForTag("h5", "text-center");
    if (testcase50) {
        testcases.testcase50 = 0.5;
    } else {
        testcases.testcase50 = 0;       
    }


    (function () {
        var sum = 0;
        for (property in testcases) {

            if (testcases[property] == 0) {
                console.error(property + "=>" + testcases[property])
            } else {
                console.log(property + "=>" + testcases[property]);
            }
            sum = sum + testcases[property];
        }

        console.log("Sum is " + sum);


        var indexData = {
            "empId": $("#tt_empId").text(),
            "examId": $("#tt_examId").text(),
            "indexTestcases": testcases,
            "registerTestcases": null,
            "register_score":null,
            "index_score":sum,
            "totalMarks": sum
        }

        console.log(indexData);
        localStorage.removeItem(indexData.empId);
        localStorage.setItem(indexData.empId, JSON.stringify(indexData));


    })();
})