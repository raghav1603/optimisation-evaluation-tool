$(document).ready(function () {

    var testcases = {};

    // for Nav bar
    var testcase1 = checkNavBarStructure();
    if (testcase1) {
        testcases.testcase1 = 0.5;
    } else {
        testcases.testcase1 = 0;
    }

    var testcase2 = checkAttributeForTag("a", "href", "index.html");
    if (testcase2) {
        testcases.testcase2 = 0.5;
    } else {
        testcases.testcase2 = 0;       // 1 mark to check if nav bar is there or not
    }

    /************************************************************************************************************* */

    //For form
    var testcase111 = checkClassNameForTag("div", "bordering");
    if (testcase111) {
        testcases.testcase111 = 0.5;
    } else {
        testcases.testcase111 = 0;
    }

    var inputMap112 = {
        1: ["col-md-4", "offset-md-4"]
    }
    var testcase112 = checkFormGrid(inputMap112);
    if (testcase112) {
        testcases.testcase112 = 1.0;
    } else {
        testcases.testcase112 = 0;
    }

    var testcase113 = checkRowCount(1);
    if (testcase113) {
        testcases.testcase113 = 0.5;
    } else {
        testcases.testcase113 = 0;                  //2 marks for centering of form and styling it 
    }


    /**************************For form elements***************************************************/
    var testcase114 = isElementPresent("event");
    if (testcase114) {
        testcases.testcase114 = 1.0;
    } else {
        testcases.testcase114 = 0;
    }

    var testcase115 = isElementPresent("user");
    if (testcase115) {
        testcases.testcase115 = 1.0;
    } else {
        testcases.testcase115 = 0;
    }

    var testcase116 = isElementPresent("not");
    if (testcase116) {
        testcases.testcase116 = 1.0;
    } else {
        testcases.testcase116 = 0;
    }

    var testcase117 = isElementPresent("doc");
    if (testcase117) {
        testcases.testcase117 = 1.0;
    } else {
        testcases.testcase117 = 0;
    }

    var testcase118 = isElementPresent("cn");
    if (testcase118) {
        testcases.testcase118 = 1.0;
    } else {
        testcases.testcase118 = 0;
    }

    var testcase119 = isElementPresent("C");
    if (testcase119) {
        testcases.testcase119 = 1.0;
    } else {
        testcases.testcase119 = 0;
    }

    var testcase120 = isElementPresent("B");
    if (testcase120) {
        testcases.testcase120 = 1.0;
    } else {
        testcases.testcase120 = 0;
    }
    var testcase200 = isElementPresent("M");
    if (testcase200) {
        testcases.testcase200 = 1.0;
    } else {
        testcases.testcase120 = 0;                                   // 8
    }

    var testcase121 = checkFormElementStructure("event");
    if (testcase121) {
        testcases.testcase121 = 0.5;
    } else {
        testcases.testcase121 = 0;
    }

    var testcase122 = checkFormElementStructure("user");
    if (testcase122) {
        testcases.testcase122 = 0.5;
    } else {
        testcases.testcase122 = 0;
    }

    var testcase123 = checkFormElementStructure("not");
    if (testcase123) {
        testcases.testcase123 = 0.5;
    } else {
        testcases.testcase123 = 0;
    }
    var testcase191 = checkFormElementStructure("doc");
    if (testcase191) {
        testcases.testcase191 = 0.5;
    } else {
        testcases.testcase191 = 0;
    }
    var testcase201 = checkFormElementStructure("cn");
    if (testcase201) {
        testcases.testcase201 = 0.5;
    } else {
        testcases.testcase201 = 0;
    }

    var testcase124 = checkLabelPresent("event");
    if (testcase124) {
        testcases.testcase124 = 0.5;
    } else {
        testcases.testcase124 = 0;
    }

    var testcase125 = checkLabelPresent("user");
    if (testcase125) {
        testcases.testcase125 = 0.5;
    } else {
        testcases.testcase125 = 0;
    }

    var testcase126 = checkLabelPresent("not");
    if (testcase126) {
        testcases.testcase126 = 0.5;
    } else {
        testcases.testcase126 = 0;
    }
    var testcase192 = checkLabelPresent("doc");
    if (testcase192) {
        testcases.testcase192 = 0.5;
    } else {
        testcases.testcase192 = 0;
    }

    var testcase202 = checkLabelPresent("cn");
    if (testcase202) {
        testcases.testcase202 = 0.5;                            //5
    } else {
        testcases.testcase202 = 0;
    }

    var testcase127 = checkClassNameForElement("event", "form-control");
    if (testcase127) {
        testcases.testcase127 = 0.25;
    } else {
        testcases.testcase127 = 0;
    }


    var testcase128 = checkClassNameForElement("user", "form-control");
    if (testcase128) {
        testcases.testcase128 = 0.25;
    } else {
        testcases.testcase128 = 0;
    }

    var testcase129 = checkClassNameForElement("not", "form-control");
    if (testcase129) {
        testcases.testcase129 = 0.25;
    } else {
        testcases.testcase129 = 0;
    }
    var testcase193 = checkClassNameForElement("doc", "form-control");
    if (testcase193) {
        testcases.testcase193 = 0.25;
    } else {
        testcases.testcase193 = 0;
    }
    var testcase203 = checkClassNameForElement("cn", "form-control");
    if (testcase203) {
        testcases.testcase203 = 0.25;
    } else {
        testcases.testcase203 = 0;
    }


    var testcase130 = checkAttributeForElement("user", "type", "text");
    if (testcase130) {
        testcases.testcase130 = 0.25;
    } else {
        testcases.testcase130 = 0;
    }


    var testcase131 = checkAttributeForElement("not", "type", "number");
    if (testcase131) {
        testcases.testcase131 = 0.25;
    } else {
        testcases.testcase131 = 0;
    }

    var testcase204 = checkAttributeForElement("not", "min", "1");
    if (testcase204) {
        testcases.testcase204 = 0.25;
    } else {
        testcases.testcase204 = 0;
    }

    var testcase132 = checkAttributeForElement("doc", "type", "date");
    if (testcase132) {
        testcases.testcase132 = 0.25;
    } else {
        testcases.testcase132 = 0;
    }

    var testcase133 = checkAttributeForElement("cn", "max", "9999999999");
    if (testcase133) {
        testcases.testcase133 = 0.25;
    } else {
        testcases.testcase133 = 0;
    }
    var testcase205 = checkAttributeForElement("cn", "min", "6000000000");
    if (testcase205) {
        testcases.testcase205 = 0.25;
    } else {
        testcases.testcase205 = 0;
    }


    var testcase134 = checkDropDownLength("event", 4);
    if (testcase134) {
        testcases.testcase134 = 0.75;
    } else {
        testcases.testcase134 = 0;
    }


    var testcase135 = checkDropDownOptions("event", ["Select an event", "Light music", "Classics", "Rock music"]);
    if (testcase135) {
        testcases.testcase135 = 0.75;
    } else {
        testcases.testcase135 = 0;
    }


    var testcase136 = checkAttributeForElement("B", "type", "radio");
    if (testcase136) {
        testcases.testcase136 = 0.25;
    } else {
        testcases.testcase136 = 0;
    }

    var testcase137 = checkAttributeForElement("M", "type", "radio");
    if (testcase137) {
        testcases.testcase137 = 0.25;
    } else {
        testcases.testcase137 = 0;
    }

    var testcase138 = checkAttributeForElement("C", "type", "radio");
    if (testcase138) {
        testcases.testcase138 = 0.25;
    } else {
        testcases.testcase138 = 0;
    }


    var testcase139 = checkRadio(3);
    if (testcase139) {
        testcases.testcase139 = 0.75;               //5.75
    } else {
        testcases.testcase139 = 0;
    }

    /**********************************************************************************************************/
    var testcase140 = checkClassNameForTag("input", "btn-primary");
    if (testcase140) {
        testcases.testcase140 = 0.5;
    } else {
        testcases.testcase140 = 0;
    }

    var testcase141 = checkClassNameForTag("input", "btn");
    if (testcase141) {
        testcases.testcase141 = 0.5;        //1
    } else {
        testcases.testcase141 = 0;
    }

    if (!testcase140 && !testcase141) {
        var testcase142 = checkClassNameForTag("button", "btn-primary");
        if (testcase142) {
            testcases.testcase142 = 0.5;
        } else {
            testcases.testcase142 = 0;
        }

        var testcase143 = checkClassNameForTag("button", "btn");
        if (testcase143) {
            testcases.testcase143 = 0.5;
        } else {
            testcases.testcase143 = 0;
        }
    }

    var testcase144 = isTagPresent("button");
    if (testcase144) {
        testcases.testcase144 = 0.5;
    } else {
        testcases.testcase144 = 0;                      //0.5
    }

    if (!testcase144) {
        var testcase145 = checkAttributeForTag("input", "type", "submit");
        if (testcase145) {
            testcases.testcase145 = 0.5;
        } else {
            testcases.testcase145 = 0;
        }
    }

    var testcase146 = checkAttributeForElement("B", "value", "B")
    if (testcase146) {
        testcases.testcase146 = 0.5;
    } else {
        testcases.testcase146 = 0;
    }

    var testcase147 = checkAttributeForElement("M", "value", "M")
    if (testcase147) {
        testcases.testcase147 = 0.5;
    } else {
        testcases.testcase147 = 0;
    }
    var testcase194 = checkAttributeForElement("C", "value", "C")
    if (testcase194) {
        testcases.testcase194 = 0.5;
    } else {
        testcases.testcase194 = 0;
    }                                                           //1.5

    var testcase148 = checkValuesForDropdown("event", ["", "Light music", "Classics", "Rock music"])
    if (testcase148) {
        testcases.testcase148 = 0.75;
    } else {
        testcases.testcase148 = 0;
    }


    var testcase149 = checkAttribute("user", "required")
    if (testcase149) {
        testcases.testcase149 = 0.5;
    } else {
        testcases.testcase149 = 0;
    }

    var testcase150 = checkAttribute("not", "required")
    if (testcase150) {
        testcases.testcase150 = 0.5;
    } else {
        testcases.testcase150 = 0;
    }

    var testcase151 = checkAttribute("doc", "required")
    if (testcase151) {
        testcases.testcase151 = 0.5;
    } else {
        testcases.testcase151 = 0;
    }

    var testcase152 = checkAttribute("cn", "required")
    if (testcase152) {
        testcases.testcase152 = 0.5;
    } else {
        testcases.testcase152 = 0;
    }
    var testcase206 = checkAttribute("B", "required")
    if (testcase206) {
        testcases.testcase206 = 0.5;
    } else {
        testcases.testcase206 = 0;
    }

    var testcase154 = checkPlaceholder("user")
    if (testcase154) {
        testcases.testcase154 = 0.5;
    } else {
        testcases.testcase154 = 0;
    }

    var testcase155 = checkPlaceholder("not")
    if (testcase155) {
        testcases.testcase155 = 0.5;
    } else {
        testcases.testcase155 = 0;
    }
    var testcase195 = checkPlaceholder("cn")
    if (testcase195) {
        testcases.testcase195 = 0.5;                    //4.75
    } else {
        testcases.testcase195 = 0;
    }

    //25 marks

    /************************************************************************************************* */
    //Bootstrap classes

    var testcase161 = checkClassNameForElement("availabilityError", "text-danger");
    if (testcase161) {
        testcases.testcase161 = 0.5;
    } else {
        testcases.testcase161 = 0;
    }

    var testcase162 = checkClassNameForElement("dateError", "text-danger");
    if (testcase162) {
        testcases.testcase162 = 0.5;
    } else {
        testcases.testcase162 = 0;
    }
    var testcase207 = checkClassNameForElement("message", "text-primary");
    if (testcase207) {
        testcases.testcase207 = 0.5;
    } else {
        testcases.testcase207 = 0;
    }

    var testcase163 = checkClassNameForElement("successMessage", "text-success");
    if (testcase163) {
        testcases.testcase163 = 0.5;
    } else {
        testcases.testcase163 = 0;
    }                                                                 //2 

    /******************************************************************************************************** */

    var testcase156 = checkAttributeForElement("user", "onkeyup", "changeToUpper()");
    if (testcase156) {
        testcases.testcase156 = 0.25;
    } else {
        testcases.testcase156 = 0;
    }

    var testcase157 = checkAttributeForElement("doc", "onchange", "checkDate()");
    if (testcase157) {
        testcases.testcase157 = 0.25;
    } else {
        testcases.testcase157 = 0;
    }

    var testcase158 = checkAttributeForElement("not", "onblur", "getTimeslot()");
    if (testcase158) {
        testcases.testcase158 = 0.25;
    } else {
        testcases.testcase158 = 0;
    }

    var testcase159 = checkAttributeForTag("form", "onsubmit", "return book()");
    if (testcase159) {
        testcases.testcase159 = 0.25;
    } else {
        testcases.testcase159 = 0;
    }

    if (!testcase156 && !testcase157 && !testcase158 && !testcase159) {
        var testcase160 = checkAttributeForElement("user", "onkeyup", "changeToUpper();");
        if (testcase160) {
            testcases.testcase160 = 0.25;
        } else {
            testcases.testcase160 = 0;
        }

        var testcase165 = checkAttributeForElement("doc", "onchange", "checkDate();");
        if (testcase165) {
            testcases.testcase165 = 0.25;
        } else {
            testcases.testcase165 = 0;
        }

        var testcase166 = checkAttributeForElement("not", "onblur", "getTimeslot();");
        if (testcase166) {
            testcases.testcase166 = 0.25;
        } else {
            testcases.testcase166 = 0;
        }

        var testcase167 = checkAttributeForTag("form", "onsubmit", " return book();");
        if (testcase167) {
            testcases.testcase167 = 0.25;
        } else {
            testcases.testcase167 = 0;
        }
    }

    if (!testcase159 && !testcase167) {
        var testcase168 = checkAttributeForTag("form", "onsubmit", "book(event)");
        if (testcase168) {
            testcases.testcase168 = 0.25;
        } else {
            testcases.testcase168 = 0;
        }
    }

    if (!testcase168) {
        var testcase174 = checkAttributeForTag("form", "onsubmit", "book(event);");
        if (testcase174) {
            testcases.testcase174 = 0.25;
        } else {
            testcases.testcase174 = 0;       //1.0 mark for function calls (10)
        }
    }

    /*********************Check for javascript functions******************************************** */

    /*-------------------------changeToUpper() func----------------------------*/

    var inputFor169 = {
        "user": "riyan"
    }
    var output169 = {
        "user": "RIYAN"
    }
    var testcase169 = testFunction2(inputFor169, output169, changeToUpper, null);
    if (testcase169) {
        testcases.testcase169 = 0.75;
    } else {
        testcases.testcase169 = 0;
    }


    var inputFor171 = {
        "user": "raman"
    }
    var output171 = {
        "user": "RAMAN"
    }

    var testcase171 = testFunction2(inputFor171, output171, changeToUpper, null);
    if (testcase171) {
        testcases.testcase171 = 0.75;
    } else {
        testcases.testcase171 = 0;
    }
    // 1 mark (9)


    /*-------------------------checkAvailability() func----------------------------*/

    var noOfTickets = 10;
    var availability = 5
    checkAvailability(availability, noOfTickets);

    var testcase172 = checkMessage("availabilityError");
    if (testcase172) {
        testcases.testcase172 = 1.25;
    } else {
        testcases.testcase172 = 0;
    }
    // 1.25 mark 

    /*-----------------checkDate() func----------------------------------*/

    var inputFor175 = {
        "doc": "2018-05-01"
    }
    var output175 = {
        "dateError": "greater"
    }

    var testcase175 = testFunction(inputFor175, output175, checkDate, null);
    if (testcase175) {
        testcases.testcase175 = 0.5;
    } else {
        testcases.testcase175 = 0;
    }

    var testcase176 = checkButtonDisability("btn", true);
    if (testcase176) {
        testcases.testcase176 = 0.25;
    } else {
        testcases.testcase176 = 0;
    }

    var testcase179 = checkMessage("dateError");
    if (testcase179) {
        testcases.testcase179 = 0.25;
    } else {
        testcases.testcase179 = 0;
    }

    var inputFor177 = {
        "doc": "2019-05-01"
    }

    var output177 = {
        "dateError": ""
    }

    var testcase177 = testFunction(inputFor177, output177, checkDate, null);
    if (testcase177) {
        testcases.testcase177 = 0.5;
    } else {
        testcases.testcase177 = 0;
    }

    var testcase178 = checkButtonDisability("btn", false);
    if (testcase178) {
        testcases.testcase178 = 0.25;
    } else {
        testcases.testcase178 = 0;
    }                                                 // 1.75 marks for checkValidate function

    /********------------------------------book func---------------------------------------******/
    if (!testcase159 && !testcase167) {
        try {
            $("form").submit(function (event) {
                //    console.log("submission", event)
                var inputFor180 = {
                    "event": "Light music",
                    "not": "2"
                }

                var output180 = {
                    "successMessage": "700"
                }

                var testcase180 = testFunction(inputFor180, output180, book, event);
                if (testcase180) {
                    testcases.testcase180 = 1.0;
                } else {
                    testcases.testcase180 = 0;
                }


                var inputFor181 = {
                    "event": "Rock music",
                    "not": "2"
                }

                var output181 = {
                    "successMessage": "800"
                }

                var testcase181 = testFunction(inputFor181, output181, book, event);
                if (testcase181) {
                    testcases.testcase181 = 1.0;
                } else {
                    testcases.testcase181 = 0;
                }

                event.preventDefault();
            });

            $("form").trigger("submit");

            var testcase182 = checkMessage("successMessage");
            if (testcase182) {
                testcases.testcase182 = 0.75;
            } else {
                testcases.testcase182 = 0;
            }

            var testcase183 = checkButtonDisability("btn", false);
            if (testcase183) {
                testcases.testcase183 = 0.25;
            } else {
                testcases.testcase183 = 0;
            }
        } catch (e) {
            console.log("Error handled", e);
            testcases.testcase181 = 0;
            testcases.testcase180 = 0;
        }

    } else {

        var inputFor180 = {
            "event": "Light music",
            "user": "RIYAN",
            "cn": "9999999999",
            "not": "2"
        }

        var output180 = {
            "successMessage": "700"
        }

        var testcase180 = testFunction(inputFor180, output180, book, null);
        if (testcase180) {
            testcases.testcase180 = 1.0;
        } else {
            testcases.testcase180 = 0;
        }

        var inputFor181 = {
            "event": "Rock music",
            "not": "2"
        }

        var output181 = {
            "successMessage": "800"
        }

        var testcase181 = testFunction(inputFor181, output181, book, null);
        if (testcase181) {
            testcases.testcase181 = 1.0;
        } else {
            testcases.testcase181 = 0;
        }

        var testcase182 = checkMessage("successMessage");
        if (testcase182) {
            testcases.testcase182 = 0.75;
        } else {
            testcases.testcase182 = 0;
        }

        var testcase183 = checkButtonDisability("btn", false);
        if (testcase183) {
            testcases.testcase183 = 0.25;
        } else {
            testcases.testcase183 = 0;
        }

    }                                // 3 marks for register function

    //---------------getTimeslot() AJAX function---------
    //2 marks
    var inputFor186 = {
        "not": "2",
        "event": "Light music"
    }

    testAjaxFunction(inputFor186, getTimeslot, null)
    setTimeout(function () {
        var message = document.getElementById("message").innerText
        var testcase186 = (document.getElementById("message").innerText.length > 1)
        var indexOfVal = message.indexOf("10:30am - 12:00pm");


        if (testcase186) {
            testcases.testcase186 = 0.75;
        } else {
            testcases.testcase186 = 0;
        }

        if (indexOfVal != -1) {
            testcases.testcase187 = 0.5;
        } else {
            testcases.testcase187 = 0;
        }

        var inputFor188 = {
            "not": "20"
        }

        testAjaxFunction(inputFor188, getTimeslot, null)
        setTimeout(function () {
            var testcase188 = (document.getElementById("availabilityError").innerHTML.length > 1)

            if (testcase188) {
                testcases.testcase188 = 0.75;
            } else {
                testcases.testcase188 = 0;
            }

            displayMarks();
        }, 500)
    }, 500)



    function displayMarks() {
        var sum = 0;
        for (property in testcases) {
            // console.log("asdad"+property);
            if (testcases[property] == 0) {
                console.error(property + "=>" + testcases[property])
            } else {
                console.log(property + "=>" + testcases[property]);
            }
            sum = sum + testcases[property];
        }
        console.log("Sum is " + sum);

        var score = JSON.parse(localStorage.getItem($("#tt_empId").text()));
        score.registerTestcases = testcases;
        score.register_score = sum;
        score.totalMarks = sum + score.totalMarks;

        console.log("Regiter score is " + JSON.stringify(score));


        var xmlhttp = new XMLHttpRequest(); // new HttpRequest instance 
        xmlhttp.open("POST", "http://localhost:3000/post");
        xmlhttp.setRequestHeader("Content-Type", "application/json");
        xmlhttp.send(JSON.stringify(score));

    };

});