var fs = require('fs');
var fse = require('fs-extra');

function addscripts() {
    hostedFolder = './hosted';
    nfiles = []
    index_file = 'index.html'
    booking_file = 'booking.html'
    index_script = './index_test_cases.js'
    booking_script = './booking_test_cases.js'
    exam_Id = 'w52404ub'
    fs.readdirSync(hostedFolder).forEach(file => {
        nfiles.push(file);
    })
    console.log("nfiles", nfiles);
    for (j = 0; j < nfiles.length; j++) {
        try {
            var counter = 0;
            fs.readdirSync('./hosted/' + nfiles[j]).forEach(file => {
                counter++;
            })
            fs.readdirSync('./hosted/' + nfiles[j]).forEach(file => {
                filename = "" + file;
                if (counter == 1) {
                    fse.copySync('./hosted/' + nfiles[j] + '/' + filename, './hosted/' + nfiles[j])
                }
            });
            // console.log(counter);
            fse.copySync('./test/testing', './hosted/' + nfiles[j]);
            indexData = `
                <div id="tt_empId">${nfiles[j]}</div>
                <div id="tt_examId">${exam_Id}</div>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
                <script src="test_tool.js"></script>
                <script src='`+ index_script + `'></script>
                <script>function Redirect() {
                    window.location='`+ booking_file + `';
                }
                document.write("You will be redirected to main page in 200 millisec.");
                setTimeout('Redirect()', 200);</script>`;
            registerData = `
            <div id="tt_empId">${nfiles[j]}</div>
            <div id="tt_examId">${exam_Id}</div>
            <script src="test_tool.js"></script>
            <script src='`+ booking_script + `'></script>`
            var path = './hosted/' + nfiles[j];
            fs.readdirSync('./hosted/' + nfiles[j]).forEach(file => {
                if (file == index_file) {
                    fs.appendFileSync('./hosted/' + nfiles[j] + '/' + file, indexData, function (err) {
                        if (err) throw err;
                    });
                }
                if (file == booking_file) {
                    fs.appendFileSync('./hosted/' + nfiles[j] + '/' + file, registerData, function (err) {
                        if (err) throw err;
                    });
                }
            });
        } catch (e) {
            console.log("Error " + e);
        }
    }
}

module.exports = addscripts();


