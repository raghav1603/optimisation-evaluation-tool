var express = require('express');
var cors = require('cors');
var app = express();
app.use(cors());


app.use(express.static("public"));
server =app.listen(5500);
console.log("Server started")