var unzip = require('unzip');
var fs = require('fs');
const p= require('path');
const testFolder = './solutions/';
// var cmd = require('node-command-line'),
// Promise = require('bluebird');

function unzip1(testFolder) {
    files = [];
    fs.readdirSync(testFolder).forEach(file => {
        files.push(file);
    })

    var directory_to_remove = './hosted/';


    /*Remove directory contents recursively */
    function removeDirectory(dirToRemove) {

        try {
            fs.readdirSync(dirToRemove).forEach(function (fileName) {

                var filePath = p.join(dirToRemove, fileName)
                var stats = fs.statSync(filePath);

                if (stats.isDirectory()) {
                    removeDirectory(filePath);
                    fs.rmdirSync(filePath);
                } else {
                    fs.unlinkSync(filePath);
                }

            });
        } catch (err) {
            console.log("files doesnt exists");
        }
    }




    if (fs.existsSync(directory_to_remove)) {
        console.log(`Removing the file ${directory_to_remove}`);
        removeDirectory(directory_to_remove);
        fs.rmdirSync(directory_to_remove);
    } else {
        console.log(`file ${directory_to_remove} not exists`);
    }

    fs.mkdirSync("./hosted");
    for (i = 0; i < files.length; i++) {
        files1 = ""
        files1 = "" + files[i] //Employee id folder names
        console.log("Files 1", files1)
        fs.mkdirSync("./hosted/" + files1.split(".")[0]); //creating the directory structure
        console.log("Files subscripted", files1.split(".")[0])
        var extractToDirectory = "./hosted/" + files1.split(".")[0];
        console.log("extractToDirectory", extractToDirectory)
        inputFileName = "./solutions/" + files[i];
        console.log('inputFileName', inputFileName)

        fs.createReadStream(inputFileName)
            .pipe(unzip.Extract({
                path: extractToDirectory
            }));
    }
}

unzip1(testFolder);
