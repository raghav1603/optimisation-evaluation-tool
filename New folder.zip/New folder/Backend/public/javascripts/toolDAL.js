var connection = require('./connections');

var toolDAL = {}


toolDAL.appendMarks = function (obj) {
    return connection.getConnection().then(function (db) {
        var my_collection = db.collection('marks');
        console.log("DAl obj",obj)
        return my_collection.insert({
            "empId": obj.empId, "examID": obj.examID,
            "indexTestCases": obj.indexTestcases, "registerTestcases": obj.registerTestcases,"totalMarks":obj.totalMarks
        }).then(function (object) {
            console.log("DAL post obj",object.ops[0])
            if(object){
                return object.ops[0]
            }
        })
    })
}

toolDAL.findEmp = function (id) {
    // console.log("Value: ",id)
    return connection.getConnection().then(function (db) {
        var my_collection = db.collection('marks');
        return db.collection("marks").find({ "examID": id }).toArray().then(function (saved) {
            // console.log("data: ",saved)
        if (!saved) throw new Error("No record with Emp Id: " + id);
        else return saved;
        })
    })
}

module.exports = toolDAL;